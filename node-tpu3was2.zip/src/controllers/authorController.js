import { Author } from "../models/Author"

  //GET /authors
export const getAuthors = async(req,res) =>{
  try{
    const authors = await Author.find().populate('libros');
    res.json(authors)
  }catch(error){
    res.status(500).json({error: 'Error al mostrar autores'})
  }
}
  //GET /authors/:id
export const getAuthorsById = async (req, res) => {
  try{
    const authors = await Author.findById(req.params.id).populate('libros');
    res.json(authors)
  }catch(error){
    res.status(500).json({error: 'Error al mostrar libros'})
  }
}
  //POST /authors
export const createAuthors= async (req,res)=> {
  try{
    const {nombre, fechaNacimiento, nacionalidad} = req.body
    if (!nombre || !fechaNacimiento || !nacionalidad){
      return res.status(404).json({error: "Campos necesarios"})
    }
    const nuevoAuthor = new Author(req.body)
    await nuevoAuthor.save()
    res.status(201).json(nuevoAuthor);
  }catch{
    res.status(400).json({error: 'Error al crear un autor'})
  }
}
  //PUT /authors/:id
export const editAuthors = async(req, res) => {
  try{
    if (!nombre || !fechaNacimiento || !nacionalidad){
      return res.status(404).json({error:})
    }
    const authorEdited = await Author.findByIdAndUpdate(req.params.id,req.body, {new:true});
    res.json(authorEdited);
  }catch(error){
    res.status(400).json({error:'Error al editar un autor', msj: error.message})
  }
}
  //DELETE /authors/:id
export const deleteAuthors = async (req, res) => {
  try{
    const authorDeleted = await Author.findByIdAndDelete(req.params.id)
    if(!authorDeleted) {
      return res.status(404).json({error:'Autor no encontrado'})
    }
    res.json(authorDeleted)
  }catch{
    res.status(401).json({error:'Error al borrar un autor'})

  }
}
  //PUT /authors/:id/addBook/:bookId 
export const addBookToAuthor = async(req, res) => {
  try{
    const author = await Author.findById(req.params.id)
    const book = await Author.findById(req.params.id)
    if(!author || !book) {
      return res.status(404).json({error:'Libro o autor no encontrado'})
    }
    if(author.includes(book)){
      return res.status(400).json({error: 'Libro duplicado'})
    }
    author.push(book)
  }catch(error){

  }
}
