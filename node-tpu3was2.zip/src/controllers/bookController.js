import { Book } from "../models/Book"

  //GET /books
export const getBooks = async (req, res) => {
  try{
    const books = await Book.find()
    res.json(books)
  }catch(error){
    res.status(500).json({error: 'Error al mostrar libros'})
  }
} 
  //GET /books/:id
export const getBooksById = async(req , res) => {
  try{
    const booksById = await Book.findById(req.params.id);
    res.json(booksById);
  }catch(error){
    res.status(500).json({error:'Error al mostrar libros'})
  }
}
  //POST /books
export const createBook = async(req, res) => {
  try{
    const{titulo,genero,publicacion,disponible} = req.body
    if(!titulo || !genero || !publicacion || !disponible ){
      return res.status(404).json({error: 'Campos necesarios'})
    }
    const nuevoBook = new Book(req.body)
    await nuevoBook.save()
    res.status(201).json(nuevoBook);
  }catch(error){
    res.status(400).json({error: 'Error al crear un libro'})
  }
}
  //PUT /books/:id
export const editBook = async(req,res) => {
  try{
    const{titulo,genero,publicacion,disponible} = req.body
    if(!titulo || !genero || !publicacion || !disponible ){
      return res.status(404).json({error: 'Campos necesarios'})
    }
    const bookEdited = Book.findByIdAndUpdate(req.params.id, req.body, {new: true})
    if(!bookEdited){
      return res.status(401).json({error: 'Error al encontrar un libro'})
    }
    await bookEdited.save()
    res.json(bookEdited);
  }catch(error){
    res.status(400).json({error: 'Error al editar un libro'})
  }
}
  //DELETE /books/:id
export const deleteBook = async(req, res) => {
  try{
    const bookEliminado = await Book.findByIdAndDelete(req.params.id);
    res.json(bookEliminado);
  }catch(error){
    res.status(400).json({error:'Error al eliminar un libreço', msj: error.message})
  }
}