import mongoose from 'mongoose'
import express from 'express'
import {authorRoute} from '../routes/authorRoute.js'
import {bookRoute} from '../routes/bookRoute.js'
import {config} from 'dotenv'
config()
const app = express()

app.use(bodyParser.json())

mongoose.connect(process.env.MONGO_URL{dbName: process.env.MONGO_DB_NAME})

const db= mongoose.connection

app.use('/authors', authorRoute)
app.use('books',bookRoute)

const port = process.env.PORT || 3000
app.listen(port, () => {
  console.log('Servidor iniciado en el puerto ',port)
})