import express from 'express'
import {getAuthors, getAuthorsById,createAuthors, editAuthors, deleteAuthors} from '../controllers/authorController.js'
const routes = express.Router()

//GET
routes.get('/',getAuthors)
//GET
routes.get('/:id',getAuthorsById)
//POST
routes.post('/', createAuthors)
//PUT
routes.put('/:id', editAuthors)
//DELTE
routes.delete('/:id', deleteAuthors)