import express from 'express'
import { createBook, deleteBook, editBook, getBooks, getBooksById } from '../controllers/bookController'

const routes = express.Router()

//GET
routes.get('/', getBooks)
//GET
routes.get('/:id', getBooksById)
//POST
routes.post('/', createBook)
//PUT
routes.put('/:id', editBook)
//DELETE
routes.delete('/:id', deleteBook)

export default routes